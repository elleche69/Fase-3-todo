  CREATE OR replace 
  
  PROCEDURE procedimiento_Ver_Trab_Por_DNI(
     dnie IN TRABAJADORESBD.DNI%TYPE,
     c_cursor out sys_refcursor)
    is
  BEGIN  
    open c_cursor for select * from TRABAJADORESBD WHERE dni = dnie;
    
  end procedimiento; 
  



















