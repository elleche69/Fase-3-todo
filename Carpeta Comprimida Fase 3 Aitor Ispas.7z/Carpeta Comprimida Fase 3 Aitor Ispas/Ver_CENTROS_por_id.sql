  CREATE OR replace 
  
  PROCEDURE procedimiento_Ver_Centros_Por_ID(
     ide IN CentrosBD.ID%TYPE,
     c_cursor out sys_refcursor)
    is
  BEGIN  
    open c_cursor for select * from CENTROSBD WHERE ID = ide;
    
  end procedimiento; 
  



















